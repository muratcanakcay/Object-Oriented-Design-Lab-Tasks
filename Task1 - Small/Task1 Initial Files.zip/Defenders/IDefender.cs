using Enemies;

namespace Defenders
{
    interface IDefender
    {
    }
}